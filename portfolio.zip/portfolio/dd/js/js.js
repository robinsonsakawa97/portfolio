function myFunction() {
  alert("please enter email");
}
function myFunction1() {
  alert("please enter text");
}